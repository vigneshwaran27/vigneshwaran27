<?php 

session_start();
  error_reporting(0);
$_SESSION["set"]=0;

?>



<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- font awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!-- Compiled and minified CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/css/materialize.min.css">
  <title>Weather</title>
  <style>
    header{
      background: url(img/3.jpg);
      background-size: cover;
      background-position: center;
      min-height: 1000px;
    }
    @media screen and (max-width: 670px){
      header{
        min-height: 500px;
      }
    }
    .section{
      padding-top: 4vw;
      padding-bottom: 4vw;
    }
    .tabs .indicator{
      background-color: #1a237e;
    }
    .tabs .tab a:focus, .tabs .tab a:focus.active{
      background: transparent;
    }

    span{
      font-size: 25px;
    }

    #result{
      font-size: 
    }
  </style>
</head>
<body>

  <!-- navbar -->
  <header>
    <nav class="nav-wrapper transparent">
      <div class="container">
        <a href="#" class="brand-logo">Weather</a>
        <a href="#" class="sidenav-trigger" data-target="mobile-menu">
          <i class="material-icons">menu</i>
        </a>
        <ul class="right hide-on-med-and-down">
          <li><a href="index.php">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Login</a></li>
          <li><a href="#" class="tooltipped btn-floating btn-small indigo darken" data-position="bottom" data-tooltip="Instagram"> 
            <i class="fab fa-instagram"></i>
          </a></li>
          <li><a href="#" class="tooltipped btn-floating btn-small indigo darken" data-position="bottom" data-tooltip="Facebook">
            <i class="fab fa-facebook"></i>
          </a></li>
          <li><a href="#" class="tooltipped btn-floating btn-small indigo darken" data-position="bottom" data-tooltip="Twitter">
            <i class="fab fa-twitter"></i>
          </a></li>
        </ul>
        <ul class="sidenav grey lighten-2" id="mobile-menu">
          <li><a href="index.php">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Login</a></li>
        </ul>
      </div>
    </nav>
    <div class="container" style="padding-top: 50px;">
      <h1 class="white-text">Enter your city</h1><br>

        <form action="process.php" method="POST">
          <div class="input-field">
            <i class="material-icons prefix white-text">search</i>
            <input type="text" name="city" id="city" class="white-text">
            <label for="city" class="white-text">Your City</label>
          </div>
          <div class="input-field center">
            <input type="submit" name="submit" id="search" value="submit" class="btn indigo" required>
          </div>
        </form>

    </div>

    <section class="section container white-text"  id="res"> 
      <div id="result" class="transparent card ">
        <?php
        //echo '<span>Your place :<span>'.$_SESSION["place"].'<br><br>';
        echo '<span>Latitude:<span>'.$_SESSION["lat"].'<br>';

        echo '<span>Longitude:<span>'.$_SESSION["lon"].'<br>';
        
        echo '<span>Cloud:<span>'.$_SESSION["cloud"].'<br>';
        
        echo '<span>Minimun temparature:<span>'.$_SESSION["temp_min"].'<br>';
        
        echo '<span>Maximum temparature:<span>'.$_SESSION["temp_max"].'<br>';
        
        echo '<span>Speed:<span>'.$_SESSION["speed"].'<br>';
        
        echo '<span>Country:<span>'.$_SESSION["country"].'<br>';
        
        echo '<span>Visibility:<span>'.$_SESSION["visibility"].'<br>';
         ?>
      </div>
    </section>

  </header>

<main></main>

  <!-- Compiled and minified JavaScript -->
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
  <script>
    $(document).ready(function(){

      

 
  </script>
</body>
</html>