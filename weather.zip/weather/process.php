<?php

session_start();

$_SESSION["set"]=1; 

$_SESSION['lat'];
$_SESSION['lon'];
$_SESSION['cloud'];
$_SESSION['temp_min'];
$_SESSION['temp_max'];
$_SESSION['speed'];
$_SESSION['country'];
$_SESSION['visibility'];
$_SESSION['place'];

if(!isset($_SESSION['lat']))
  $_SESSION['lat']=0;

echo $_SESSION['lat'];

if(!isset($_SESSION['lat']))
  $_SESSION['lon']=0;

if(!isset($_SESSION['lat']))
  $_SESSION['country']=0;

if(!isset($_SESSION['lat']))
  $_SESSION['visibility']=0;

if(!isset($_SESSION['lat']))
  $_SESSION['temp_max']=0;

if(!isset($_SESSION['lat']))
  $_SESSION['temp_max']=0;

if(!isset($_SESSION['lat']))
  $_SESSION['cloud']=0;


$city= $_POST['city'];

$_SESSION["place"] = $_POST['city'];
$api = "4695f498a395d6b15c36c4ed06f55635";

//echo $first_name;

$url = "http://api.openweathermap.org/data/2.5/weather?APPID=".$api."&q=".$city;

$curl = curl_init();

curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HEADER, 0);  
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);  


$json = curl_exec($curl);
//$json = {"coord":{"lon":80.28,"lat":13.09},"weather":[{"id":802,"main":"Clouds","description":"scattered clouds","icon":"03d"}],"base":"stations","main":{"temp":311.15,"pressure":1003,"humidity":37,"temp_min":311.15,"temp_max":311.15},"visibility":7000,"wind":{"speed":3.6,"deg":260},"clouds":{"all":40},"dt":1532772000,"sys":{"type":1,"id":7834,"message":0.0062,"country":"IN","sunrise":1532737408,"sunset":1532783230},"id":1264527,"name":"Chennai","cod":200};
//echo $json;

$data = json_decode($json, 1);
//print_r($data);

//echo $data["coord"]=>{["lon"]};

//echo $data["coord"]["id"];

//echo $data["coord"]["lat"]."<br>";
$_SESSION["lat"] = $data["coord"]["lat"]."<br>";
//echo $_SESSION["lat"];

$_SESSION["lon"] = $data["coord"]["lon"]."<br>";
$_SESSION["cloud"] = $data["weather"][0]["description"]."<br>";
$_SESSION["temp_min"] = $data["main"]["temp_min"]."<br>";
$_SESSION["temp_max"] = $data["main"]["temp_max"]."<br>";
$_SESSION["speed"] = $data["wind"]["speed"]."<br>";
$_SESSION["country"] =  $data["sys"]["country"]."<br>";
$_SESSION["visibility"] = $data["visibility"];
//var_dump($data);


//echo $json;
curl_close($curl);

header("Location: weather.php");
